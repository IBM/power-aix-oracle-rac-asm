Role Name
=========

Ensure the basic AIX environment - time, oslevel, CPU, memory

Requirements
------------

Role Variables
--------------

Dependencies
------------

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - preconfig

License
-------

Apache-2.0

Author Information
------------------

Tommy Tse
